#include <cstdio>

int main()
{
    printf("hello from vntactd!\n");
    return 0;
}